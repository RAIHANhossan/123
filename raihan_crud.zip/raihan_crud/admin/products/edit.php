


<?php
$webroot = "http://localhost/raihan_crud/";
$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "";


 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "SELECT * FROM product WHERE id = :id";
 $stmt = $conn->prepare($query);
 $stmt->bindParam(':id', $id);
 $result = $stmt->execute();

 $single_product = $stmt->fetch();

//  var_dump($banner);

?>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Products</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
  </head>
  <body>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6">
                <h1 class="text-center mb-3">Add New</h1>
                <form action="update.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3 row">
                        <label for="inputTilte" class="col-sm-2 col-form-label">Title</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="inputTilte" name="title" value="<?= $single_product['title']?>">
                        </div>
                    </div>

                    <div class="mb-3 row">
                        <label for="inputSDes" class="col-sm-2 col-form-label">Short Description</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="inputSDes" name="s_des" value="<?= $single_product['short_description']?>">
                        </div>
                    </div>

                    <div class="mb-3 row">
                        <label for="inputDes" class="col-sm-2 col-form-label">Description</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="inputDes" name="des" value="<?= $single_product['description']?>">
                        </div>
                    </div>

                    <div class="mb-3 row">
                        <label for="productType" class="col-sm-2 col-form-label">Product Category</label>
                        <div class="col-sm-10">

                        <?php
                            $servername = "localhost";
                            $username = "root";
                            $password = "";
                            
                            
                             $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
                             // set the PDO error mode to exception
                             $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                            
                             $query = "SELECT * FROM categories";
                             $stmt = $conn->prepare($query);
                             $result = $stmt->execute();
                            
                             $banners = $stmt->fetchAll();
                            
                            //  var_dump($banners);
                        ?>

                        <select name="product_category" id="">
                            <option value="" disabled>Select Category</option>
                            <option value="<?= $single_product['product_type']?>" selected><?= $single_product['product_type']?></option>
                            <?php foreach($banners as $banner):?>
                            <option value="<?= $banner['name'];?>" ><?= $banner['name'];?></option>
                            <?php endforeach;?>
                        </select>
                        </div>
                    </div>

                    <div class="mb-3 row">
                        <label for="price" class="col-sm-2 col-form-label">Price</label>
                        <div class="col-sm-10">
                        <input type="number" class="form-control" id="price" name="price" value="<?= $single_product['price']?>">
                        </div>
                    </div>

                   <div class="mb-3 form-check">

                        <?php
                            if($single_product['is_active'] == 0){
                        ?>
                            <input type="checkbox" class="form-check-input" id="inputIsActive" name="is_active" value="1">
                        <?php
                            }else{
                        ?>
                            <input type="checkbox" class="form-check-input" id="inputIsActive" name="is_active" value="1" checked>
                        <?php
                            };
                        ?>
                        <label for="inputIsActive">Is active</label>
                    </div>

                    <div class="mb-3">
                        <label for="formFile" class="form-label">Picture</label>
                        <input class="form-control" type="file" id="formFile" name="picture" value="<?= $single_product['picture']?>">
                    </div>
                    
                    <img src="<?= $webroot?>uploads/<?= $single_product['picture'];?>" alt="" width="200px">
                    
                    <input type="hidden" name="old_picture" value="<?= $single_product['picture']?>">

                    
                    
                    <input type="hidden" name="update_id" value="<?= $single_product['id']?>">

                     <br><br><br>       
                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>




    
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>
</html>