
<?php

$servername = "localhost";
$username = "root";
$password = "";


 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "SELECT * FROM product";
 $stmt = $conn->prepare($query);
 $result = $stmt->execute();

 $banners = $stmt->fetchAll();

//  var_dump($banners);



 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
 </head>
 <body>
<section>
<div class="container">
    <div class="row justyfy-content-center">
        <div class="col-6">
            <h1></h1>

        </div>

    </div>
</div>
</section>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6">
                <h1 class="text-center mb-3">Lists</h1> <a href="create.php" id="add_product">Add Product</a>
                <a href="../category/add_category.php" class="add_category">Add Category</a>
                <table class="table table-bordered mt-3" style="text-align: center">
                    <thead>
                        <th scope="col">ID</th>
                        <th scope="col">Title</th>
                        <th scope="col">action</th>
                    </thead>

                    <?php
                        foreach($banners as $banner):
                    ?>
                    <tbody>
                        <tr>
                            <td><?= $banner['id'];?></td>
                            <td><?= $banner['title'];?></td>
                            <td>
                                <a href="show.php?id=<?= $banner['id']?>" id="show">Show</a> 
                                | <a href="edit.php?id=<?= $banner['id'];?>" id="edit">Edit</a> 
                                | <a href="delete.php?id=<?= $banner['id'];?>" onclick="alert('are you sure want to remove this data?')" id="delete">Delete</a></td>
                                
                        </tr>
                    </tbody>
                    <?php
                    endforeach;
                    ?>
                </table>
            </div>
        </div>
    </div>


 <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
 </body>
 </html>