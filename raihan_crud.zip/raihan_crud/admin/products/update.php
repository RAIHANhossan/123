<?php
$approot = $_SERVER['DOCUMENT_ROOT']."/raihan_crud/";

$_title = $_POST['title'];
$_short_des = $_POST['s_des'];
$_long_des = $_POST['des'];
$_porduct_category = $_POST['product_category'];
$_price = $_POST['price'];
$_update_id = $_POST['update_id'];



if($_FILES['picture']['name'] != ""){
    $file_name = "IMG_".time()."_".$_FILES['picture']['name'];
    $target = $_FILES['picture']['tmp_name'];
    $destination = $approot."uploads/".$file_name;

    $is_file_moved = move_uploaded_file($target, $destination);
    unlink($approot."uploads/".$_POST['old_picture']);
    if($is_file_moved){
        $_picture = $file_name;
    }else{
        $_picture = null;
    }
}else{
    $_picture = $_POST['old_picture'];
}

if(array_key_exists('is_active', $_POST)){
    $_is_active = $_POST['is_active'];
}else{
    $_is_active = 0;
}


$servername = "localhost";
$username = "root";
$password = "";



 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);

 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "UPDATE product SET title = :title, picture = :picture, short_description = :short_des, description = :long_des, product_type = :porduct_cat, price = :price, is_active = :is_active WHERE product.id = :u_id";

 $stmt = $conn->prepare($query);

 $stmt->bindParam(':u_id', $_update_id);
 $stmt->bindParam(':title', $_title);
 $stmt->bindParam(':picture', $_picture);
 $stmt->bindParam(':short_des', $_short_des);
 $stmt->bindParam(':long_des', $_long_des);
 $stmt->bindParam(':porduct_cat', $_porduct_category);
 $stmt->bindParam(':price', $_price);
 $stmt->bindParam(':is_active', $_is_active);
 
 
 $result = $stmt->execute();


//  header("location:add_category.php");


//  $banner = $stmt->fetch();

//  var_dump($banner);
header('location:index.php');

?>