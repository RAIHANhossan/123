<?php

$webroot = "http://localhost/raihan_crud/";
$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "";


 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "SELECT * FROM product WHERE id = :id";
 $stmt = $conn->prepare($query);
 $stmt->bindParam(':id', $id);
 $result = $stmt->execute();

 $banner = $stmt->fetch();

//  var_dump($banner);

?>

<!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
 </head>
 <body>

    <div class="container">
        <div class="row justify-content-center">
                <h1 class="text-center mb-3">Show</h1>
                <table class="table" id="show_table">
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Title</th>
                            <th scope="col">Short Description</th>
                            <th scope="col">Description</th>
                            <th scope="col">Produt Type</th>
                            <th scope="col">Picture</th>
                            <th scope="col">active/Deactive</th>
                            <th scope="col">Created Date</th>
                            <th scope="col">Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?= $banner['id']?></td>
                            <td><?= $banner['title']?></td>
                            <td><?= $banner['short_description']?></td>
                            <td><?= $banner['description']?></td>
                            <td><?= $banner['product_type']?></td>
                            <td>
                                <img src="<?= $webroot;?>uploads/<?= $banner['picture']?>" alt="<?= $banner['picture']?>" width="100px">
                            </td>
                            <td><?= $banner['is_active']? 'Active':'Deactive';?></td>
                            <td><?= $banner['created_at']?></td>
                            <td><?= $banner['price']?> Taka</td>
                        </tr>
                    </tbody>
                </table>
        
        </div>
    </div>


 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
 </body>
 </html>