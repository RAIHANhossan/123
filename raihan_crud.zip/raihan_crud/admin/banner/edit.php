
<?php
$webroot = "http://localhost/crud/";
$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "";


 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "SELECT * FROM banners WHERE id = :id";
 $stmt = $conn->prepare($query);
 $stmt->bindParam(':id', $id);
 $result = $stmt->execute();

 $single_product = $stmt->fetch();

//  var_dump($banner);

?>


<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Products</title>
    <link rel="stylesheet" href="../css_and_bootstrap/css/style.css">
  </head>
  <body>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6">
                <h1 class="text-center mb-3">Add Banner</h1>
                <form action="update.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3 row">
                        <label for="inputTilte" class="col-sm-2 col-form-label">Title</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="inputTilte" name="title" value="<?= $single_product['title'];?>">
                        </div>
                    </div>

                    <div class="mb-3 row">
                        <label for="inputSDes" class="col-sm-2 col-form-label">Promotion Message</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="inputSDes" name="p_message" value="<?= $single_product['promotional_message'];?>">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="formFile" class="form-label">Picture</label>
                        <input class="form-control" type="file" id="formFile" name="picture">
                    </div>

                    <div class="mb-3 form-check">

                        <?php
                            if($single_product['is_active'] == 0){
                        ?>
                            <input type="checkbox" class="form-check-input" id="inputIsActive" name="is_active" value="1">
                        <?php
                            }else{
                        ?>
                            <input type="checkbox" class="form-check-input" id="inputIsActive" name="is_active" value="1" checked>
                        <?php
                            };
                        ?>
                        <label for="inputIsActive">Is active</label>
                    </div>
                    <input type="hidden" name="id" value="<?= $single_product['id']?>">
                    <input type="hidden" name="old_picture" value="<?= $single_product['picture'];?>">

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>




    
    <script src="../css_and_bootstrap/bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>
</html>