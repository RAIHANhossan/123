
<?php
$webroot = "http://localhost/raihan_crud/";
$servername = "localhost";
$username = "root";
$password = "";


 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "SELECT * FROM banners";
 $stmt = $conn->prepare($query);
 $result = $stmt->execute();

 $banners = $stmt->fetchAll();

//  var_dump($banners);



 ?>

 <!DOCTYPE html>
 <html lang="en">
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="<?= $webroot?>admin/products/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
 </head>
 <body>

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6">
                <h1 class="text-center mb-3">Lists</h1>
                <table class="table table-bordered" style="text-align: center">
                    <thead>
                        <th scope="col">Banner Name</th>
                        <th scope="col">is active</th>
                        <th scope="col">Creation date and time</th>
                        <th scope="col">Updated date and time</th>
                        <th scope="col">Image</th>
                        <th scope="col">Action</th>
                    </thead>

                    <?php
                        foreach($banners as $banner):
                    ?>
                    <tbody>
                        <tr>
                            <td><?= $banner['title'];?></td>
                            <td><?= $banner['is_active'] ? 'active':'deactive';?></td>
                            <td><?= $banner['created_at'];?></td>
                            <td><?= $banner['modified_at'];?></td>
                            <td><img src="<?= $webroot?>uploads/<?= $banner['picture'];?>" alt="" width="150px"></td>
                            <td><a href="edit.php?id=<?= $banner['id'];?>" id="show">Edit</a> | <a href="delete.php?id=<?= $banner['id'];?>" onclick="alert('are you sure want to remove this data?')" id="delete">Delete</a></td>
                        </tr>
                    </tbody>
                    <?php
                    endforeach;
                    ?>
                </table>
            </div>
        </div>
    </div>


 <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
 </body>
 </html>