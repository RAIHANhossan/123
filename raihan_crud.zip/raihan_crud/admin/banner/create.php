

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Products</title>
    <link rel="stylesheet" href="../css_and_bootstrap/css/style.css">
  </head>
  <body>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6">
                <h1 class="text-center mb-3">Add Banner</h1>
                <form action="store.php" method="post" enctype="multipart/form-data">
                    
                    <div class="mb-3 row">
                        <label for="inputTilte" class="col-sm-2 col-form-label">Title</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="inputTilte" name="title" value="">
                        </div>
                    </div>

                    <div class="mb-3 row">
                        <label for="inputSDes" class="col-sm-2 col-form-label">Promotion Message</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="inputSDes" name="p_message" value="">
                        </div>
                    </div>

                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="inputIsActive" name="is_active" value="1">
                        <label for="inputIsActive">Is active</label>
                    </div>

                    <div class="mb-3">
                        <label for="formFile" class="form-label">Picture</label>
                        <input class="form-control" type="file" id="formFile" name="picture">
                    </div>

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>




    
    <script src="../css_and_bootstrap/bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>
</html>