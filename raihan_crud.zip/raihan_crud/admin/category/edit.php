<?php
$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "";


 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "SELECT * FROM categories WHERE id = :id";
 $stmt = $conn->prepare($query);
 $stmt->bindParam(':id', $id);
 $result = $stmt->execute();

 $single_product = $stmt->fetch();

//  var_dump($banner);

?>



<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Products</title>
    <link rel="stylesheet" href="../products/bootstrap/css/bootstrap.min.css">
  </head>
  <body>
    
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-6">
                <h1 class="text-center mb-3">Edit Category</h1>
                <form action="update.php" method="post" enctype="multipart/form-data">
                    <div class="mb-3 row">
                        <label for="inputTilte" class="col-sm-2 col-form-label">Category Name</label>
                        <div class="col-sm-10">
                        <input type="text" class="form-control" id="inputTilte" name="title" value="<?= $single_product['name']?>">
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="date_time" class="form-label">Updated date</label>
                        <input type="datetime-local" class="form-control" id="date_time" name="updated_date">
                    </div>

                    <input type="hidden" name="update_id" value="<?= $single_product['id']?>">

                    <button type="submit" class="btn btn-primary">Submit</button>
                </form>
            </div>
        </div>
    </div>




    
    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
  </body>
</html>