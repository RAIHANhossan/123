<?php

// echo "<pre>";
// print_r($_POST);
// echo "</pre>";
// die();


$cat_name = $_POST['cat_name'];
$created_date = $_POST['created_date'];


if(array_key_exists('is_active', $_POST)){
    $_is_active = $_POST['is_active'];
}else{
    $_is_active = 0;
}


$servername = "localhost";
$username = "root";
$password = "";

 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "INSERT INTO categories(name, is_active, created_at) VALUE(:c_name, :c_is_active, :c_date)";
 $stmt = $conn->prepare($query);
 $stmt->bindParam(':c_name', $cat_name);
 $stmt->bindParam(':c_is_active', $_is_active);
 $stmt->bindParam(':c_date', $created_date);
 $result = $stmt->execute();
 header("location:add_category.php");


//  $banner = $stmt->fetch();

//  var_dump($banner);

?>