

<?php
$_id = $_POST['update_id'];
$_edited_name = $_POST['title'];
$_updated_date = $_POST['updated_date'];


$servername = "localhost";
$username = "root";
$password = "";


 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "UPDATE categories SET name=:name, modified_at=:modified_date WHERE id = :id";

 $stmt = $conn->prepare($query);
 $stmt->bindParam(':id', $_id);
 $stmt->bindParam(':name', $_edited_name);
 $stmt->bindParam(':modified_date', $_updated_date);
 $result = $stmt->execute();

 header('location:index.php');

//  $single_product = $stmt->fetch();

//  var_dump($banner);

?>