<?php

$id=$_GET['id'];
$servername = "localhost";
$username = "root";
$password = "";

 $conn = new PDO("mysql:host=$servername;dbname=ecommmerce", $username, $password);
 // set the PDO error mode to exception
 $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

 $query = "DELETE FROM categories WHERE id = :id";
 $stmt = $conn->prepare($query);
 $stmt->bindParam(':id', $id);
 $result = $stmt->execute();

 header("location:index.php");

//  $banner = $stmt->fetch();

//  var_dump($banner);

?>
