

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../products/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../products/style.css">
</head>
<body>
    <div class="container">
        <h1>Add Category</h1> <a href="index.php" id="cat_to_list_button">Go Category List</a>
            <form action="add_category_action.php" method="post">
                <div class="mb-3">
                    <label for="categoryName" class="form-label">Category Name</label>
                    <input type="text" class="form-control" id="categoryName" name="cat_name">
                </div>

                <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="inputIsActive" name="is_active" value="1">
                    <label for="inputIsActive">Is active</label>
                </div>
                
                <div class="mb-3">
                    <label for="date_time" class="form-label">Created date</label>
                    <input type="datetime-local" class="form-control" id="date_time" name="created_date">
                </div>
                <button type="submit" id="add_category_button">Add</button>
            </form>
            </div>
    </div>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>